/**
 * 
 */
/**
 * @author Mahreen-PC
 *
 */
module Practical5 {
}