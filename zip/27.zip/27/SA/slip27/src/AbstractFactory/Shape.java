package AbstractFactory;

public interface Shape {
	void draw();
}
