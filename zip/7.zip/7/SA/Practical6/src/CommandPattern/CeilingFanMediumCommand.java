package CommandPattern;

public class CeilingFanMediumCommand implements Command{

	public CeilingFanMediumCommand(CeilingFan ceilingFan) {}
	public void CeilingFanMediumCommand(CeilingFan ceilingFan) {}
	@Override
	public void execute() {}
	@Override
	public void undo() {}
	
}
